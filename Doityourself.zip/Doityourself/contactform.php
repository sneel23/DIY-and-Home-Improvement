<?php
if (isset ($_POST['email']))
{
$name = $_POST['name'];
$to = "ashokaglobal2020@gmail.com";
$subject = $_POST['subject'];
$phone =  $_POST['phone'];
$txt = $_POST['message'];
$from = $_POST['email'];
$txt1 = $_POST['phone'];
$headers= "From: info@ashokaglobalsolutions.com\r\n";
$headers .= "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$txt="Following inquiry has been received via web form.<br>
<b>Name:</b> $name<br>
<b>Phone:</b> $phone<br>
<b>Email:</b> $from<br>
<b>Message:</b> $txt<br>
<b>Contact:</b> $txt1<br>
";
  mail($to,$subject,nl2br($txt),$headers);  
  echo 'OK';
}
?>